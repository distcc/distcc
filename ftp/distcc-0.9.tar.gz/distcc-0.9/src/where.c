/* -*- c-file-style: "java"; indent-tabs-mode: nil -*-
 * 
 * distcc -- A simple distributed compiler system
 * $Header: /data/cvs/distcc/src/where.c,v 1.29 2002/08/31 22:30:25 mbp Exp $ 
 *
 * Copyright (C) 2002 by Martin Pool <mbp@samba.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 */


                /* His hand is stretched out, and who shall turn it
                 * back?  -- Isaiah 14:27 */

    
/**
 * @file
 *
 * Routines to look at the <tt>$DISCC_HOSTS</tt> and decide where to
 * run a job.
 *
 * We use a simple locking algorithm to try to make sure work is fairly
 * evenly distributed across all hosts.
 *
 * For each destination host, we keep a lock file in the temporary
 * directory.  A lock is held on that file all the time that a client
 * is connected to it, so that other invocations of distcc on the same
 * client machine by the same user can synchronize with it.
 *
 * There are an unbounded number of lock files for each volunteer,
 * from 0 up.  We repeatedly walk through all the volunteers in order
 * until we find a lock file that is not locked; we then try to
 * connect to that server.
 *
 * So whatever -j value you give to make, you should end up with
 * roughly that number of tasks running at any time, except that
 * remote tasks may be deferred in their accept queue until the
 * machine is ready to serve them.
 *
 * We use locks rather than e.g. deleting files because we want to
 * make sure that the lock will be removed if the client terminates
 * unexpectedly.  There is in fact no explicit unlock: the lock goes
 * away when the client terminates.
 *
 * The files themselves (as opposed to the lock on them) is never
 * cleaned up; since locking & creation is nonatomic I can't think of
 * a clean way to do it.  There shouldn't be many of them, and dead
 * ones will be caught by the tmpreaper.  In any case they're zero
 * bytes.
 *
 * Semaphores might work well here, but the interface is a bit ugly
 * and they have a reputation for being nonportable.
 */

#define _GNU_SOURCE

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>

#include <sys/stat.h>
#include <sys/file.h>

#include "distcc.h"
#include "trace.h"
#include "io.h"
#include "util.h"
#include "rpc.h"
#include "hosts.h"
#include "tempfile.h"


/* TODO: Write a test harness for the host selection algorithm.
 * Perhaps a really simple simulation of machines taking different
 * amounts of time to build stuff? */

/* TODO: Lock files ought to incorporate port. */

/* TODO: Lock files ought to also incorporate IP address, so that we
 * can use multi-A records for round-robin assignment. */

static char * dcc_make_lock_filename(const char *host, int iter)
{
    int need_len;
    char * buf;
    const char *tempdir;

    tempdir = dcc_get_tempdir();
    need_len = strlen(tempdir) + 6 + strlen(host) + 1 + 7 + 1;
    buf = malloc(need_len);
    if (snprintf(buf, need_len, "%s/lock_%s_%07d", tempdir, host, iter)
        != need_len - 1) {
        rs_fatal("wrong length??");
    }
    return buf;
}


/**
 * Get an exclusive, non-blocking lock on a file using whatever method
 * is available on this system.
 *
 * @return 0 if we got the lock; -1 with EAGAIN if the file is already
 * locked.
 **/
static int sys_lock(int fd)
{
#if defined(F_SETLK)
    struct flock lockparam;

    lockparam.l_type = F_WRLCK;
    lockparam.l_whence = SEEK_SET;
    lockparam.l_start = 0;
    lockparam.l_len = 0;        /* whole file */
    
    return fcntl(fd, F_SETLK, &lockparam);
#elif defined(HAVE_FLOCK)
    return flock(fd, LOCK_EX|LOCK_NB);
#elif defined(HAVE_LOCKF)
    return lockf(fd, F_TLOCK, 0);
#else
#  error "No supported lock method.  Please port this code."
#endif
}


static int dcc_try_lock_host(struct dcc_hostdef *host, int iter)
{
    const char *tempdir;
    char *fname;
    int fd;
    int ret;

    tempdir = dcc_get_tempdir();
    fname = dcc_make_lock_filename(host->hostname, iter);

    /* Create if it doesn't exist.  We don't actually do anything with
     * the file except lock it.*/
    if ((fd = open(fname, O_WRONLY|O_CREAT, 0600)) == -1
        && errno != EEXIST) {
        rs_log_error("failed to creat %s: %s", fname, strerror(errno));
        goto bomb;
    }

    ret = sys_lock(fd);
    
    if (ret != -1) {
        rs_trace("locked %s", fname);
        free(fname);
        return 0;
    } else
        switch (errno) {
#ifdef EWOULDBLOCK
        case EWOULDBLOCK:
#endif
#if defined(EAGAIN) && EAGAIN != EWOULDBLOCK
        case EAGAIN:
#endif
            rs_trace("%s already locked", fname);
            break;
        default:
            rs_log_error("flock %s failed: %s", fname, strerror(errno));
            break;
    }

    bomb:
    free(fname);
    return -1;
}


int dcc_pick_buildhost(const struct dcc_hostdef **buildhost)
{
    int i_try;
    int n_hosts;
    struct dcc_hostdef *hostlist, *h;
    int ret;

    if ((ret = dcc_parse_hosts_env(&hostlist, &n_hosts)) != 0) {
        /* an error occured; but let's be helpful and build locally
         * rather than giving up. */
        *buildhost = dcc_hostdef_local;
        return 0;
    }

    for (i_try = 0; i_try < 50; i_try++) {
        for (h = hostlist; h; h = h->next) {
            if (dcc_try_lock_host(h, i_try) == 0) {
                rs_trace("building on %s", h->hostname);
                *buildhost = h;
                return 0;
            }
        }
    }
    
    rs_log_warning("couldn't lock any of the %d defined hosts!", n_hosts);
    *buildhost = dcc_hostdef_local;
    return 0;
}
