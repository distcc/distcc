#! /bin/sh

# Run this script to build distcc from CVS.

# $Header: /data/cvs/distcc/autogen.sh,v 1.5 2002/06/02 03:55:17 mbp Exp $

if which automake >/dev/null
then
    :
else
    echo "$0: need automake-1.5 or later to build distcc from CVS" >&2
    exit 1
fi

if which autoconf > /dev/null
then
    :
else
    echo "$0: need autoconf 2.53 or later to build distcc from CVS" >&2
    exit 1
fi

if test \! -f ChangeLog
then
    echo "$0: ChangeLog is missing.  An empty stub will be created" >&2
    echo "Use \"make always_ChangeLog\" to build it from CVS" >&2
    touch ChangeLog
fi

echo "$0: running aclocal to install aclocal.m4"
aclocal

echo "$0: running autoheader"
autoheader

echo "$0: running automake"
automake --add-missing --copy
echo "$0: running autoconf"
autoconf
echo "now run ./configure and then make"
exit 0
