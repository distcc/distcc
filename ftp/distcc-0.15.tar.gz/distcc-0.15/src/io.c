/* -*- c-file-style: "java"; indent-tabs-mode: nil; fill-column: 78 -*-
 * 
 * distcc -- A simple distributed compiler system
 * $Header: /data/cvs/distcc/src/io.c,v 1.46 2002/11/01 08:06:20 mbp Exp $ 
 *
 * Copyright (C) 2002 by Martin Pool <mbp@samba.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 */


                        /* "I've always wanted to use sendfile(), but
                         * never had a reason until now"
                         *              -- mbp                        */


/**
 * @file
 *
 * Common low-level IO utilities.
 *
 * The pump_* methods are for doing bulk transfer of the entire
 * contents of a file to or from the socket.  We have various
 * different implementations to suit different circumstances.
 *
 * This code is not meant to know about our protocol, only to provide
 * a more comfortable layer on top of Unix IO.
 *
 * @todo Perhaps also add a method of copying that truncates and mmaps
 * the destination file, and then writes directly into it.
 *
 * @todo Perhaps also add a pump method that mmaps the input file, and
 * writes from there to the output file.
 **/

/*
 * TODO: Perhaps write things out using writev() to reduce the number
 * of system calls, and the risk of small packets when not using
 * TCP_CORK.
 *
 * TODO: Check for every call to read(), write(), and other long
 * system calls.  Make sure they handle EINTR appropriately.
 */

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <assert.h>

#include <sys/stat.h>
#ifdef HAVE_SYS_SENDFILE_H
#  include <sys/sendfile.h>
#endif /* !HAVE_SYS_SENDFILE_H */
#include <sys/types.h>
#include <sys/socket.h>

#include <netinet/in.h>
#include <netinet/tcp.h>

#include "distcc.h"
#include "trace.h"
#include "io.h"
#include "util.h"
#include "exitcode.h"


#ifdef HAVE_SENDFILE
/* If you don't have it, just use dcc_pump_readwrite */




/**
 * Map FreeBSD and Linux into something like the Linux interface.
 *
 * Our sockets are never non-blocking, so that seems to me to say that
 * the kernel will never return EAGAIN -- we will always either send
 * the whole thing or get an error.  Is that really true?
 *
 * How nice to have the function parameters reversed between platforms
 * in a way that will not give a compiler warning.
 *
 * @param offset offset in input to start writing; updated on return
 * to reflect the number of bytes sent.
 *
 * @return number of bytes sent; -1 otherwise, with errno set.  (As
 * for Linux)
 *
 * @sa http://www.freebsd.org/cgi/man.cgi?query=sendfile&sektion=2&apropos=0&manpath=FreeBSD+5.0-current
 **/


#ifdef __FreeBSD__
static ssize_t sys_sendfile(int ofd, int ifd, off_t *offset, size_t size)
{
    off_t sent_bytes;
    int ret;
    
    /* According to the manual, this can never partially complete on a
     * socket open for blocking IO. */
    ret = sendfile(ifd, ofd, offset, size, 0, &sent_bytes, 0);
    if (ret == -1) {
        if (errno == EAGAIN) {
            return sent_bytes;
        } else {
            return -1;
        }
    } else if (ret == 0) {
        return size;
    } else {
        rs_log_error("don't know how to handle return %d from BSD sendfile",
                     ret);
        return -1;
    }
}
#else  /* ! __FreeBSD__ */
static ssize_t sys_sendfile(int ofd, int ifd, off_t *offset, size_t size)
{
    return sendfile(ofd, ifd, offset, size);
}
#endif /* !__FreeBSD__ */


/**
 * Transmit the body of a file using sendfile().
 *
 * If the sendfile() call fails in a way that makes us think that
 * regular IO might work, then we try that instead.  For example, the
 * /tmp filesystem may not support sendfile().
 *
 * @param ofd Output fd
 * @param ifd Input file (must allow mmap)
 **/
int dcc_pump_sendfile(int ofd, int ifd, size_t size)
{
    ssize_t sent;
    off_t offset = 0;

    while (size) {
        /* Handle possibility of partial transmission, e.g. if
         * sendfile() is interrupted by a signal.  size is decremented
         * as we go. */

        sent = sys_sendfile(ofd, ifd, &offset, size);
        if (sent == -1) {
            if ((errno == ENOSYS || errno == EINVAL) && offset == 0) {
                /* The offset==0 tests is because if we're partway through the
                 * file then something else must have happened; obviously the
                 * filesystem didn't change partway through.  We can't just
                 * naively go back to read/write because sendfile() does not
                 * update the file pointer: we would need to lseek() first. */
                rs_log_info("sendfile failed, falling back to read/write: %s: "
                            "(perhaps you're using tmpfs?)",
                            strerror(errno));
                /* pass remainder to read/write */
                return dcc_pump_readwrite(ofd, ifd, size);
            } else {
                rs_log_error("sendfile failed: %s", strerror(errno));
                return -1;
            }
        } else if (sent == 0) {
            rs_log_error("sendfile returned 0? can't cope");
            return -1;
        } else if (sent != (ssize_t) size) {
            /* offset is automatically updated by sendfile. d'oh. */
            size -= sent;
            rs_log_notice("sendfile: partial transmission of %d bytes; retrying %ld @%ld",
                          sent, (long) size, (long) offset);
        } else {
            /* normal case, everything was sent. */
            break;
        }
    }
    return 0;
}
#endif /* def HAVE_SENDFILE */


/**
 * Copy @p n bytes from @p ifd to @p ofd.
 *
 * Does not use sendfile(), so @p ifd may be a socket.
 **/
int dcc_pump_readwrite(int ofd, int ifd, size_t n)
{
    char buf[60000], *p;
    ssize_t r_in, r_out, wanted;

    while (n > 0) {
         wanted = (n > sizeof buf) ? (sizeof buf) : n;
         r_in = read(ifd, buf, (size_t) wanted);
         
         if (r_in == -1) {
            rs_log_error("failed to read %ld bytes: %s",
                         (long) wanted, strerror(errno));
            return -1;
         } else if (r_in == 0) {
              break;	/* great */
         }
         
        n -= r_in;
        p = buf;

        while (r_in > 0) {
            r_out = write(ofd, p, (size_t) r_in);
            if (r_out == -1  ||  r_out == 0) {
                rs_log_error("failed to write: %s", strerror(errno));
                return EXIT_IO_ERROR;
            }
            r_in -= r_out;
            p += r_out;
        }
    }

    return 0;
}



int dcc_readx(int fd,  void *buf, size_t len)
{
	ssize_t r;
	
	while (len > 0) {
		r = read(fd, buf, len);
		if (r == -1) {
			rs_log_error("failed to read: %s", strerror(errno));
                        return EXIT_IO_ERROR;
		} else if (r == 0) {
			rs_log_error("unexpected eof on fd%d", fd);
			return EXIT_TRUNCATED;
		} else {
			buf = &((char *) buf)[r];
			len -= r;
		}
	}

	return 0;
}


int dcc_writex(int fd, const void *buf, size_t len)
{
    ssize_t r;
	
    while (len > 0) {
        r = write(fd, buf, len);
        if (r == -1) {
            rs_log_error("failed to write: %s", strerror(errno));
            return EXIT_IO_ERROR;
        } else if (r == 0) {
            rs_log_error("unexpected eof on fd%d", fd);
            return EXIT_TRUNCATED;
        } else {
            buf = &((char *) buf)[r];
            len -= r;
        }
    }

    return 0;
}


int dcc_write_str(int fd, const char *what)
{
    return dcc_writex(fd, what, strlen(what));
}


int dcc_r_str_alloc(int fd, int l, char **buf)
{
     char *s;

     assert(l > 0);

/*      rs_trace("read %d byte string", l); */

     s = *buf = malloc((size_t) l + 1);
     if (!s)
          rs_log_error("malloc failed");
     if (dcc_readx(fd, s, (size_t) l))
          return EXIT_OUT_OF_MEMORY;

     s[l] = 0;

     return 0;
}


int dcc_write_int(int fd, unsigned v)
{
	char buf[10];
	sprintf(buf, "%08x", v);
	return dcc_writex(fd, buf, 8);
}



int dcc_read_int(int fd, unsigned *v)
{
    char buf[9], *bum;
    int ret;    
	
    if ((ret = dcc_readx(fd, buf, 8)))
        return ret;
    buf[8] = 0;
    
    *v = (unsigned) strtoul(buf, &bum, 16);
    if (bum != &buf[8]) {
        rs_log_error("failed to parse integer %s", buf);
        return EXIT_PROTOCOL_ERROR;
    }

    return 0;
}



/**
 * Stick a TCP cork in the socket.  It's not clear that this will help
 * performance, but it might.
 *
 * This is a no-op if we don't think this platform has corks.
 **/
int tcp_cork_sock(int fd, int corked)
{
#ifdef TCP_CORK 
    if (!dcc_getenv_bool("DISTCC_TCP_CORK", 1))
        return 0;
    
    if (setsockopt(fd, SOL_TCP, TCP_CORK, &corked, sizeof corked) == -1) {
        rs_log_notice("setsockopt(corked=%d) failed: %s",
                      corked, strerror(errno));
        /* continue anyhow */
    }
#endif /* def TCP_CORK */
    return 0;
}



int dcc_close(int fd)
{
    if (close(fd) != 0) {
        rs_log_error("failed to close fd%d: %s", fd, strerror(errno));
        return EXIT_IO_ERROR;
    }
    return 0;
}
