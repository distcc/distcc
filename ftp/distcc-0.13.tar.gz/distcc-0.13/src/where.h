/* where.c */
int dcc_random_block(const char *what,
		     struct dcc_hostdef *hostlist,
                     struct dcc_hostdef **buildhost);
int dcc_pick_buildhost(const char *what,
		       struct dcc_hostdef **);
int dcc_lock_one(const char *what,
                 struct dcc_hostdef *hostlist, struct dcc_hostdef **buildhost);
