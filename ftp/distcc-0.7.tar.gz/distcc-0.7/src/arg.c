/* -*- c-file-style: "java"; indent-tabs-mode: nil -*- 
 *
 * distcc -- A simple distributed compiler system
 * $Header: /data/cvs/distcc/src/arg.c,v 1.52 2002/08/02 04:19:58 mbp Exp $ 
 *
 * Copyright (C) 2002 by Martin Pool <mbp@samba.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 */


                /* "I have a bone to pick, and a few to break."
                 *     -- Anonymous */


#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#include <sys/stat.h>

#include "distcc.h"
#include "trace.h"
#include "io.h"
#include "util.h"
#include "exitcode.h"


static int dcc_argv_append(char *argv[], char *toadd)
{
    int l = dcc_argv_len(argv);
    argv[l] = toadd;
    argv[l+1] = NULL;           /* just make sure */
    return 0;
}


/**
 * Parse arguments, extract ones we care about, and also work out
 * whether it will be possible to distribute this invocation remotely.
 *
 * This is a little hard because the cc argument rules are pretty
 * complex, but the function still ought to be simpler than it already
 * is.
 *
 * The few options explicitly handled by the client are processed in its
 * main().  At the moment, this is just --help and --version, so this function
 * never has to worry about them.
 *
 * We recognize two basic forms "distcc gcc ..." and "distcc ...", with no
 * explicit compiler name.  This second one is used if you have a Makefile
 * that can't manage two-word values for $CC; eventually it might support
 * putting a link to distcc on your path as 'gcc'.  We call this second one an
 * implicit compiler.
 *
 * We need to distinguish the two by working out whether the first argument
 * "looks like" a compiler name or not.  I think the two cases in which we
 * should assume it's implicit are "distcc -c hello.c" (starts with a hypen),
 * and "distcc hello.c" (starts with a source filename.)
 *
 * In the case of implicit compilation "distcc --help" will always give you
 * distcc's help, not gcc's, and similarly for --version.  I don't see much
 * that we can do about that.
 *
 * @todo To fully support implicit compilers, we ought to call the child with
 * an environment variable set to protect against infinite (>1) recursion.
 *
 * This code is called on both the client and the server, though they use the
 * results differently.  So it does not directly cause any actions, but only
 * updates fields in @p jobinfo.
 *
 * @retval 0 if it's ok to distribute this compilation.
 *
 * @retval -1 if it would be unsafe to distribute this compilation.
 *
 * @todo Fix this to use standard return codes.
 **/
int dcc_scan_args(char *argv[], char **input_file, char **output_file,
                  char ***ret_newargv)
{
    int seen_opt_c = 0, seen_opt_s = 0;
    int i;
    char *a;
    char *argstr;
    int ret;

     /* allow for -o foo.o */
    if ((ret = dcc_shallowcopy_argv(argv, ret_newargv, 2)) != 0)
        return ret;
    argv = *ret_newargv;

    argstr = dcc_argv_tostr(argv);
    rs_trace("scanning arguments: %s", argstr);
    free(argstr);

    /* At the moment, we cannot handle "distcc -c hello.c", but we should in
     * the future. */
    if (argv[0][0] == '-') {
        rs_log_error("unrecognized distcc option: %s", argv[0]);
        exit(EXIT_BAD_ARGUMENTS);
    }

    *input_file = *output_file = NULL;

    for (i = 0; (a = argv[i]); i++) {
        if (a[0] == '-') {
            if (!strcmp(a, "-E")) {
                rs_trace("-E call for cpp must be local");
                return -1;
            } else if (a[1] == 'M') {
                /* -M causes the preprocessor to produce a list of make-style
                    dependencies on header files, either to stdout or to a
                    local file.  It implies -E, so only the preprocessor is
                    run, not the compiler.  There would be no point trying to
                    distribute it even if we could. */
                rs_trace("-M<anything> for cpp must be local");
                return -1;
            } else if (!strcmp(a, "-S")) {
                seen_opt_s = 1;
            } else if (!strcmp(a, "-fprofile-arcs")
                       || !strcmp(a, "-ftest-coverage")) {
                rs_log_info("compiler will emit profile info; must be local");
                return -1;
            } else if (!strcmp(a, "-x")) {
                /* TODO: We could also detect options like "-x
                 * cpp-output" or "-x assembler-with-cpp", because they
                 * should override language detection based on
                 * extension.  I haven't seen anyone use them yet
                 * though. */

                rs_log_info("gcc's -x handling is complex; running locally");
                return -1;
            } else if (!strcmp(a, "-c")) {
                seen_opt_c = 1;
            } else if (!strcmp(a, "-o")) {
                /* Whatever follows must be the output */
                a = argv[++i];
                goto GOT_OUTPUT;
            } else if (str_startswith("-o", a)) {
                a += 2;         /* skip "-o" */
                goto GOT_OUTPUT;
            }
        } else {
            if (dcc_is_source(a)) {
                rs_trace("found input file \"%s\"", a);
                if (*input_file) {
                    rs_log_notice("do we have two inputs?  i give up");
                    return -1;
                }
                *input_file = a;
            } else if (str_endswith(".o", a)) {
              GOT_OUTPUT:
                rs_trace("found object file \"%s\"", a);
                if (*output_file) {
                    rs_log_notice("called for link?  i give up");
                    return -1;
                }
                *output_file = a;
            }
        }
    }

    /* TODO: ccache has the heuristic of ignoring arguments that do
     * not exist when looking for the input file; that's possibly
     * worthwile. */

    if (!seen_opt_c && !seen_opt_s) {
        rs_log_notice("compiler apparently called not for compile");
        return -1;
    }

    if (!*input_file) {
        rs_log_notice("no visible input file");
        return -1;
    }

    if (!*output_file) {
        /* This is a commandline like "gcc -c hello.c".  They want
         * hello.o, but they don't say so.  For example, the Ethereal
         * makefile does this. */
        /* FIXME: This doesn't handle a.out, but that doesn't matter.
         */
        char *ofile;
        if (seen_opt_c) {
            if (dcc_output_from_source(*input_file, ".o", &ofile))
                return -1;
        } else if (seen_opt_s) {
            if (dcc_output_from_source(*input_file, ".s", &ofile))
                return -1; 
        } else {
            rs_log_crit("this can't be happening(%d)!", __LINE__);
            return -1;
        }
        rs_log_notice("no visible output file, going to add \"-o %s\" at end",
                      ofile);
        dcc_argv_append(argv, "-o");
        dcc_argv_append(argv, ofile);
        *output_file = ofile;
    }

    rs_log(RS_LOG_INFO|RS_LOG_NONAME, "compile from %s to %s", *input_file, *output_file);

    return 0;
}


int
dcc_argv_len (char **a)
{
  int i;

  for (i = 0; a[i]; i++)
    ;
  return i;
}

/**
 * Adds @p delta extra NULL arguments, to allow for adding more
 * arguments later.
 **/
int dcc_shallowcopy_argv(char **from, /*@-nullstate@*/ char ***out, int delta)
{
    /*@null@*/ char **b;
    int l, i;

    assert(out != NULL);
    assert(from != NULL);

    l = dcc_argv_len(from);
    b = malloc((l+1+delta) * (sizeof from[0]));
    if (b == NULL) {
        rs_log_error("failed to allocate copy of argv");
        exit(EXIT_FAILURE);
    }
    for (i = 0; i < l; i++) {
        b[i] = from[i];
    }
    b[l] = NULL;
    
    *out = b;

    return 0;
}


/**
 * Adds @p delta extra NULL arguments, to allow for adding more
 * arguments later.
 **/
int dcc_deepcopy_argv(char **from, /*@-nullstate@*/ char ***out)
{
    char **b;
    int i, l;

    l = dcc_argv_len(from);
    
    assert(out != NULL);
    assert(from != NULL);

    l = dcc_argv_len(from);
    b = malloc((l+1) * (sizeof from[0]));
    if (b == NULL) {
        rs_log_error("failed to allocate copy of argv");
        exit(EXIT_FAILURE);
    }

    for (i = 0; i < l; i++) 
        b[i] = strdup(from[i]);
    b[l] = NULL;

    *out = b;

    return 0;
}


/**
 * Used to change "-c" or "-S" to "-E", so that we get preprocessed
 * source.
 **/
int dcc_set_action_opt(char **a, char *new_c)
{
    int gotone = 0;
    
    for (; *a; a++) 
        if (!strcmp(*a, "-c") || !strcmp(*a, "-S")) {
            *a = strdup(new_c);
            if (*a == NULL) {
                rs_log_error("strdup failed");
                exit(EXIT_FAILURE);
            }
            gotone = 1;
            /* keep going; it's not impossible they wrote "gcc -c -c
             * -c hello.c" */
        }

    if (!gotone) {
        rs_log_error("failed to find -c or -S");
        return -1;
    } else {
        return 0;
    }
}



/**
 * Change object file or suffix of -o to @ofname
 *
 * It's crucially important that in every case where an output file is
 * detected by dcc_scan_args(), it's also correctly identified here.
 * It might be better to make the code shared.
 **/
int dcc_set_output(char **a, char *ofname)
{
    int i;
    
    for (i = 0; a[i]; i++) 
        if (0==strcmp(a[i], "-o")  &&  a[i+1] != NULL) {
            rs_trace("changed output from \"%s\" to \"%s\"", a[i+1], ofname);
            a[i+1] = ofname;
            rs_trace("command after: %s", dcc_argv_tostr(a));
            return 0;
        }
    /* TODO: Handle -ofoo.o */

    rs_log_error("failed to find \"-o\"");
    return -1;
}


/**
 * Change input file to @ifname; called on compiler.
 *
 * @todo Unify this with dcc_scan_args
 **/
int dcc_set_input(char **a, char *ifname)
{
    int i;
    
    rs_trace("command before: %s", dcc_argv_tostr(a));

    for (i =0; a[i]; i++)
        if (dcc_is_source(a[i])) {
            rs_trace("changed input from \"%s\" to \"%s\"", a[i], ifname);
            a[i] = ifname;
            rs_trace("command after: %s", dcc_argv_tostr(a));
            return 0;
        }
    
    rs_log_error("failed to find input file");
    return -1;
}


/**
 * @return newly-allocated string containing representation of
 * arguments.
 **/
char *dcc_argv_tostr(char **a)
{
    int l, i;
    char *s, *ss;
    
    /* calculate total length */
    for (l = 0, i = 0; a[i]; i++) {
        l += strlen(a[i]) + 3;  /* two quotes and space */
    }

    ss = s = malloc((size_t) l + 1);
    if (!s) {
        rs_log_crit("failed to allocate %d bytes", l+1);
        exit(EXIT_OUT_OF_MEMORY);
    }
    
    for (i = 0; a[i]; i++) {
        /* kind of half-assed quoting; won't handle strings containing
         * quotes properly, but good enough for debug messages for the
         * moment. */
        int needs_quotes = (strpbrk(a[i], " \t\n\"\';") != NULL);
        if (i)
            *ss++ = ' ';
        if (needs_quotes)
            *ss++ = '"';
        strcpy(ss, a[i]);
        ss += strlen(a[i]);
        if (needs_quotes)
            *ss++ = '"';
    }
    *ss = '\0';

    return s;
}


