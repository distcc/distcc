/* -*- c-file-style: "java"; indent-tabs-mode: nil -*-
 * 
 * distcc -- A simple distributed compiler system
 * $Header: /data/cvs/distcc/src/exec.c,v 1.39 2002/08/02 04:58:43 mbp Exp $ 
 *
 * Copyright (C) 2002 by Martin Pool <mbp@samba.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 */


			/* 18 Their bows also shall dash the young men
			 * to pieces; and they shall have no pity on
			 * the fruit of the womb; their eyes shall not
			 * spare children.
			 *		-- Isaiah 13 */

/**
 * @file
 *
 * Run compilers.
 *
 * @todo Use pipes to talk to the compiler rather than temporary
 * files.  In fact, we might simply just use named pipes directly in
 * place of the temporary files.  We need to make sure to start the
 * compiler *before* we start writing, in that case.  It seems that
 * this works for gcc's input, but it needs to seek on the output.
 * This makes sense -- object files are likely to be assembled in
 * random order, but cc1 needs to be able to read from a pipe.  This
 * will allow at least a bit more overlap between network IO and CPU
 * load on the server, which ought to be good.  The .o file is not so
 * important because it's much smaller.
 *
 * @todo On Cygwin, fork() must be emulated and therefore will be
 * slow.  It would be faster to just use their spawn() call, rather
 * than fork/exec.
 **/


#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/resource.h>

#include "distcc.h"
#include "trace.h"
#include "io.h"
#include "util.h"
#include "exitcode.h"

/* You can't have core files on Windows. */
#ifndef WCOREDUMP
#  define WCOREDUMP(status) 0
#endif

void dcc_note_execution(const char *hostname, char **argv)
{
    char *astr;

    astr = dcc_argv_tostr(argv);
    rs_log(RS_LOG_INFO|RS_LOG_NONAME, "exec on %s: %s", hostname, astr);
    free(astr);
}


/**
 * Redirect stdin/out/err.  Filenames may be NULL to leave them untouched.
 *
 * This is called when running a job remotely, but *not* when running
 * it locally, because people might e.g. want cpp to read from stdin.
 **/
int dcc_redirect_fds(const char *stdin_file,
                     const char *stdout_file,
                     const char *stderr_file)
{
    /* XXX: tridge warns that O_CREAT ought to use O_EXCL */
    if (stdin_file)
        redirect_fd(STDIN_FILENO, stdin_file, O_RDONLY);
    if (stdout_file)
        redirect_fd(STDOUT_FILENO, stdout_file, O_WRONLY|O_CREAT|O_EXCL);
    if (stderr_file)
        redirect_fd(STDERR_FILENO, stderr_file, O_WRONLY|O_CREAT|O_EXCL);

    return 0;
}


/**
 * Replace this program with another in the same process.
 *
 * Does not return, either execs the compiler in place, or exits with
 * a message.
 **/
void dcc_execvp(char **argv)
{
    execvp(argv[0], argv);
    
    /* shouldn't be reached */
    rs_log_error("failed to exec %s: %s", argv[0], strerror(errno));

    dcc_exit(EXIT_COMPILER_CRASHED); /* not strictly accurate */
}



/**
 * Run @p argv in a child asynchronously.
 *
 * stdin, stdout and stderr are redirected as shown, unless those
 * filenames are NULL.
 *
 * @warning When called on the daemon, where stdin/stdout may refer to random
 * network sockets, all of the standard file descriptors must be redirected!
 **/
int dcc_spawn_child(char **argv, pid_t *pidptr,
                    const char *stdin_file,
                    const char *stdout_file,
                    const char *stderr_file)
{
    pid_t pid;

    rs_trace("forking to execute %s", dcc_argv_tostr(argv));
    
    pid = fork();
    if (pid == -1) {
        rs_log_error("failed to fork: %s", strerror(errno));
        return -1;
    } else if (pid == 0) {
        dcc_redirect_fds(stdin_file, stdout_file, stderr_file);
        dcc_execvp(argv);
    } else {
        *pidptr = pid;
        rs_trace("child started as pid%d", (int) pid);
        return 0;
    }
}


/**
 * Blocking wait for a child to exit.  This is used when waiting for
 * cpp, gcc, etc.
 *
 * This is not used by the daemon-parent; it has its own
 * implementation in dcc_reap_kids().  They could be unified, but the
 * parent only waits when it thinks a child has exited; the child
 * waits all the time.
 **/
int dcc_collect_child(pid_t pid, int *wait_status, long *u_us, long *s_us)
{
    struct rusage ru;
    
    /* TODO: Need to parse command result; command failing does
     * not mean we want to give up straight away, because the
     * client needs to see errors, warning messages, etc. */
    while (1) {
        if (wait4(pid, wait_status, 0, &ru) != -1) {
            /* This is not the main user-visible message, that comes from
             * critique_status(). */
            rs_trace("child %d terminated with status %#x", pid, *wait_status);
            *u_us = ru.ru_utime.tv_sec * 1000000 + ru.ru_utime.tv_usec;
            *s_us = ru.ru_stime.tv_sec * 1000000 + ru.ru_stime.tv_usec;
            return 0;
        } else if (errno == EINTR) {
            /* huh, try again */
            continue;
        } else {
            rs_log_error("waitpid pid%d borked: %s", (int) pid, strerror(errno));
            return -1;
        }
    }
}


/**
 * Report child's resource usage in readable format.
 **/
int dcc_report_rusage(const char *command,
                      long utime_usec,
                      long stime_usec)
{
    rs_log_info("%s resource usage: %ld.%06lds user, %ld.%06lds system",
                command, utime_usec/1000000, utime_usec%1000000,
                stime_usec/1000000, stime_usec%1000000);
    return 0;
}


/**
 * Analyze and report on a command's exit code.
 *
 * @param command short human-readable description of the command (perhaps
 * argv[0])
 *
 * @returns 0 if the command succeeded; EXIT_COMPILER_CRASHED if it did;
 * otherwise the command's exit code.
 **/
int dcc_critique_status(int s, const char *command,
                        const char *hostname)
{
    if (WIFSIGNALED(s)) {
        rs_log_error("%s on %s died with signal %d%s",
                     command, hostname,
                     WTERMSIG(s),
                     WCOREDUMP(s) ? " (core dumped)" : "");
        return EXIT_COMPILER_CRASHED;
    } else if (WEXITSTATUS(s)) {
        rs_log_error("%s on %s failed with exit code %d",
                     command, hostname,
                     WEXITSTATUS(s));
        return WEXITSTATUS(s);
    } else {
        rs_log(RS_LOG_INFO|RS_LOG_NONAME,
               "%s on %s completed ok", command, hostname);
        return 0;
    }
}

