/* -*- c-file-style: "java"; indent-tabs-mode: nil -*-
 * 
 * distcc -- A simple distributed compiler system
 * $Header: /data/cvs/distcc/src/dparent.c,v 1.25 2002/08/02 04:23:42 mbp Exp $ 
 *
 * Copyright (C) 2002 by Martin Pool <mbp@samba.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 */


		/* I don't know that atheists should be considered as
		 * citizens, nor should they be considered patriots.
		 * This is one nation under God.
		 * -- Vice President, George H. W. Bush, 1987 */


/**
 * @file
 *
 * Daemon parent.  Accepts connections, forks, etc.
 *
 * @todo Quite soon we need load management.  Basically when we think
 * we're "too busy" we should stop accepting connections.  This could
 * be because of the load average, or because too many jobs are
 * running, or perhaps just because of a signal from the administrator
 * of this machine.  In that case we want to do a blocking wait() to
 * find out when the current jobs are done, or perhaps a sleep() if
 * we're waiting for the load average to go back down.  However, we
 * probably ought to always keep at least one job running so that we
 * can make progress through the queue.  If you don't want any work
 * done, you should kill the daemon altogether.
 **/

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <syslog.h>
#include <signal.h>
#include <fcntl.h>

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/ioctl.h>

#include "exitcode.h"
#include "distcc.h"
#include "trace.h"
#include "io.h"
#include "util.h"
#include "opt.h"

#ifndef WAIT_ANY
#  define WAIT_ANY (-1)
#endif

static int dcc_start_child(int listen_fd, int);
static volatile int parent_exit_signal = 0;
static void dcc_parent_loop(int listen_fd) NORETURN;
static void dcc_parent_signalled(int);
static void dcc_catch_signals(void);
static void dcc_parent_terminate(void) NORETURN;
static int dcc_serve_connection(int, int acc_fd);
static void dcc_become_daemon(void);
static void dcc_remove_pid(void);
static void dcc_save_pid(void);

static int nkids = 0;


/**
 * Be a standalone server, with responsibility for sockets and forking
 * children.  Puts the daemon in the background and detaches from the
 * controlling tty.
 **/
int dcc_standalone_server(void)
{
    int listen_fd;
    int ret;

    if ((ret = dcc_refuse_root()) != 0)
        return ret;
    
    if ((listen_fd = open_socket_in(arg_port)) == -1)
        return EXIT_BIND_FAILED;

    rs_log(RS_LOG_INFO|RS_LOG_NONAME,
           "distccd (version %s, built %s %s) listening on port %d",
           PACKAGE_VERSION, __DATE__, __TIME__, arg_port);

    dcc_catch_signals();

    if (!arg_no_fork) {
        /* Don't go into the background until we're listening and
         * ready.  This is useful for testing -- when the daemon
         * detaches, we know we can go ahead and try to connect.  */
        dcc_become_daemon();
    }

    dcc_save_pid();
    
    dcc_parent_loop(listen_fd);		/* noreturn */
}


/**
 * Catch and remember various fatal signals, which will cause the
 * parent and all children to exit.
 **/
static void dcc_parent_signalled(int whichsig)
{
    parent_exit_signal = whichsig;
}


/**
 * Signal handler for SIGCHLD.  Does nothing, but calling into this
 * ought to make us break out of the pause().
 **/
static void dcc_child_exited(int UNUSED(whichsig))
{
}


/**
 * Signals are caught only in the parent at the moment, because we
 * want to be able to kill off all children and log a message when
 * exiting.  This is perhaps not the best thing to do -- it might be
 * better to simply let ourselves be terminated, and for children to
 * go away when they're finished their current work.  If the admin is
 * really impatient, they can kill all the children anyhow.
 **/
static void dcc_catch_signals(void)
{
#if 0
    struct sigaction act_catch, act_exited;

    memset(&act_catch, 0, sizeof act_catch);
    act_catch.sa_handler = dcc_parent_signalled;

    memset(&act_exited, 0, sizeof act_exited);
    act_exited.sa_handler = dcc_child_exited;
    act_exited.sa_flags = SA_NOCLDSTOP;

    if (sigaction(SIGTERM, &act_catch, NULL)
        || sigaction(SIGHUP, &act_catch, NULL)
        || sigaction(SIGINT, &act_catch, NULL)
        || sigaction(SIGQUIT, &act_catch, NULL)
        || sigaction(SIGCHLD, &act_exited, NULL)) {
        rs_log_error("failed to install signal handlers: %s",
                     strerror(errno));
    }
#endif
}


/**
 * @sa dcc_wait_child(), which is used by a process that wants to do a blocking
 * wait for some task like cpp or gcc.
 **/
static void dcc_reap_kids(void)
{
    while (1) {
        int status;
        pid_t kid;

        kid = waitpid(WAIT_ANY, &status, WNOHANG);
        if (kid == 0) {
            break;
        } else if (kid != -1) {
            /* child exited */
            --nkids;
            rs_log_info("down to %d kids", nkids);
            
            if (WIFSIGNALED(status)) {
                rs_log_error("child %d exited on signal %d",
                             (int) kid, WTERMSIG(status));
            } else if (WIFEXITED(status)) {
                rs_log_notice("child %d exited: status %d",
                              (int) kid, WEXITSTATUS(status));
            }
        } else if (errno == ECHILD) {
            /* No children left?  That's ok, we'll go back to waiting
             * for new connections. */
            break;          
        } else if (errno == EINTR) {
            /* If we got a SIGTERM or something, then on the next pass
             * through the loop we'll find no children done, and we'll
             * return to the top loop at which point we'll exit.  So
             * no special action is required here. */
            continue;       /* loop again */
        } else {
            rs_log_error("wait failed: %s", strerror(errno));
            dcc_exit(EXIT_DISTCC_FAILED);
        }
    }
}


/**
 * Main loop for the parent process.  Basically it does nothing but
 * wait around to be signalled, or for its children to die.  What a
 * life!
 **/
static void dcc_parent_loop(int listen_fd)
{
    while (parent_exit_signal == 0) {
        int acc_fd;

        rs_log_info("waiting to accept connection");
        acc_fd = accept(listen_fd, NULL, 0);
        if (acc_fd == -1 && errno == EINTR) {
            /* just go ahead and check for children */
        }  else if (acc_fd == -1) {
            rs_log_error("accept failed: %s", strerror(errno));
            dcc_exit(EXIT_CONNECT_FAILED);
        } else {
            dcc_serve_connection(listen_fd, acc_fd);
        }

        dcc_reap_kids();
    }

    dcc_parent_terminate();
}


/**
 * Called in the daemon parent when a connection is received.  Either
 * forks a new child, or handles it in the process (debug mode), as
 * appropriate.
 **/
static int dcc_serve_connection(int listen_fd, int acc_fd)
{
    int ret = 0;
    
    if (arg_no_fork) {
        ret = dcc_accept_job(acc_fd);
        dcc_cleanup_tempfiles();
    } else {
        dcc_start_child(listen_fd, acc_fd);
        ++nkids;
        rs_log_info("up to %d children", nkids);
    }
    if (close(acc_fd)) {          /* in parent */
        rs_log_error("failed to close accept fd%d: %s", acc_fd,
                     strerror(errno));
    }

    return ret;
}


/**
 * Kill all children and exit.
 *
 * Called when the parent gets a signal.
 **/
static void dcc_parent_terminate(void)
{
    /* Kill our process group -- not including ourselves because we're
     * still protected. */
    rs_log_notice("terminating process group on signal %d\n", parent_exit_signal);
    if (kill(0, SIGTERM)) {
        rs_log_error("failed to kill our process group: %s", strerror(errno));
    }
    
    dcc_remove_pid();

    /* Remove protection, then kill ourselves */
    signal(parent_exit_signal, SIG_DFL);
    if (kill(getpid(), parent_exit_signal)) {
        rs_log_error("kill failed: %s", strerror(errno));
    }

    rs_log_notice("\"you feel very ill\"");
    dcc_exit(EXIT_SUCCESS);
}


static int dcc_start_child(int listen_fd, int accepted_fd)
{
    pid_t kid;
    int ret, close_ret;
    
    kid = fork();
    if (kid == 0) {
        close(listen_fd);
        ret = dcc_accept_job(accepted_fd);
        close_ret = dcc_close(accepted_fd);
        dcc_exit(ret ? ret : close_ret);
        /* doesn't return */
    } else if (kid == -1) {
        rs_log_error("fork failed: %s", strerror(errno));
        return -1;
    }

    return 0;
}


/**
 * Save the pid of the current process into the pid file, if any.
 **/
static void dcc_save_pid(void)
{
    FILE *fp;
    
    if (!arg_pid_file)
        return;

    if (!(fp = fopen(arg_pid_file, "wt"))) {
        rs_log_error("failed to open pid file: %s: %s", arg_pid_file,
                     strerror(errno));
        return;
    }

    fprintf(fp, "%ld\n", (long) getpid());

    if (fclose(fp) == -1) {
        rs_log_error("failed to close pid file: %s: %s", arg_pid_file,
                     strerror(errno));
        return;
    }

    atexit(dcc_remove_pid);
}


/**
 * Remove our pid file on exit.
 **/
static void dcc_remove_pid(void)
{
    if (!arg_pid_file)
        return;

#if 0
    if (unlink(arg_pid_file)) {
        rs_log_warning("failed to remove pid file %s: %s",
                       arg_pid_file, strerror(errno));
    }
#endif
}


/**
 * Become a daemon, discarding the controlling terminal.
 *
 * Borrowed from rsync.
 *
 * This function returns in the child, but not in the parent.
 **/
static void dcc_become_daemon(void)
{
    int i;

    /* Kill off intermediate child */
    if (fork()) {
        /* We don't want to bother with atexit() functions in the
         * intermediate */
        _exit(0);
    }

    /* detach from the terminal */
#ifdef HAVE_SETSID
    setsid();
#else
#ifdef TIOCNOTTY
    i = open("/dev/tty", O_RDWR);
    if (i >= 0) {
        ioctl(i, (int) TIOCNOTTY, (char *)0);      
        close(i);
    }
#endif /* TIOCNOTTY */
#endif
    /* make sure that stdin, stdout an stderr don't stuff things
       up (library functions, for example) */
    for (i=0;i<3;i++) {
        close(i); 
        open("/dev/null", O_RDWR);
    }
}
