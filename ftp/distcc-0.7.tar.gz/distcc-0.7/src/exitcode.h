/* -*- c-file-style: "gnu"; indent-tabs-mode: nil -*-
 * 
 * distcc -- A simple distributed compiler system
 * $Id: exitcode.h,v 1.7 2002/07/24 08:48:30 mbp Exp $ 
 *
 * Copyright (C) 2002 by Martin Pool <mbp@samba.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 */

/**
 * @file
 *
 * Common exit codes.
 **/

/**
 * Common exit codes for both client and server.
 *
 * These need to be in [1,255] so that they can be used as exit()
 * codes.
 *
 * @todo We ought to migrate to the more standard convention of
 * returning 128+signal for exits on a signal.
 **/
enum {
  EXIT_DISTCC_FAILED            = 100,
  EXIT_BAD_ARGUMENTS            = 101,
  EXIT_BIND_FAILED              = 102,
  EXIT_CONNECT_FAILED           = 103,
  EXIT_COMPILER_CRASHED         = 104,
  EXIT_OUT_OF_MEMORY            = 105,
  EXIT_BAD_HOSTSPEC             = 106
};
