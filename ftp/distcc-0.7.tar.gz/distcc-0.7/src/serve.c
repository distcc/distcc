/* -*- c-file-style: "java"; indent-tabs-mode: nil -*-
 * 
 * distcc -- A simple distributed compiler system
 * $Header: /data/cvs/distcc/src/serve.c,v 1.30 2002/08/05 09:46:33 mbp Exp $ 
 *
 * Copyright (C) 2002 by Martin Pool <mbp@samba.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 */

                /* He who waits until circumstances completely favour *
                 * his undertaking will never accomplish anything.    *
                 *              -- Martin Luther                      */
   

/**
 * @file
 *
 * Actually serve remote requests.  Called from daemon.c.
 *
 * @todo When a request arrives, we should start writing diagnostic
 * messages on the server to a temporary stderr file, as well as to
 * syslog (or the daemon's overall output file.)  We can ship it back
 * as well, and the client will be able to see what went wrong.  I
 * don't think there's any strong reason to keep it separate from the
 * compiler's output.  To be useful, this probably means that the
 * client has to pass a -v level to the server -- the server's rs_log
 * hook can check against that.
 *
 * @todo Don't send the status back as a single packed integer, but
 * rather as a set of fields (exit code, signal, others?)  This is
 * necessary because the way it's encoded may vary between platforms.
 * This requires a protocol bump.
 *
 * @todo Add a command to return the daemon's version and perhaps
 * some information about the machine.  Should include hostname,
 * distcc version, perhaps the system's uptime as well. 
 *
 * @todo If the client's sending us a .s file, then we need the
 * temporary file to be called .s as well.  In fact the server
 * needs to map from input filename to temporary filename
 * extension to make sure the right language type is invoked.
 * .cxx -> .ii, .S -> .s, etc. 
 **/


#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#ifdef HAVE_SYS_SIGNAL_H
#  include <sys/signal.h>
#endif /* HAVE_SYS_SIGNAL_H */

#include "distcc.h"
#include "trace.h"
#include "io.h"
#include "util.h"
#include "rpc.h"
#include "exitcode.h"
#include "opt.h"


static int dcc_r_request_header(int ifd)
{
    unsigned vers;
    
    if (dcc_expect_token(ifd, "DIST") == -1) {
        rs_log_error("client did not provide distcc magic fairy dust");
        return -1;
    }

    if (dcc_read_int(ifd, &vers) == -1) {
        rs_log_error("didn't get remote version");
        return -1;
    }

    if (vers != 1) {
        rs_log_error("client version is %d, i am %d", vers, 1);
        return -1;
    }
    
    return 0;
}


/**
 * Read an argv[] vector from the network.
 **/
static int dcc_r_argv(int ifd, /*@out@*/ char ***argv)
{
    unsigned i;
    unsigned argc;
    char **a;

    *argv = NULL;
     
    if (dcc_expect_token(ifd, "ARGC"))
        return -1;

    if (dcc_read_int(ifd, &argc))
         return -1;
    
    rs_trace("reading %d arguments from job submission", argc);
    
    /* Have to make the argv one element too long, so that it can be
     * terminated by a null element. */
    *argv = a = (char **) calloc((size_t) argc+1, sizeof a[0]);
    if (a == NULL) {
        rs_log_error("alloc failed");
        return -1;
    }
    a[argc] = NULL;

    for (i = 0; i < argc; i++) {
        if (dcc_expect_token(ifd, "ARGV")
            || dcc_r_str_alloc(ifd, &a[i]))
            return -1;
        
        rs_trace("argv[%d] = \"%s\"", i, a[i]);
    }
    
    return 0;
}


/**
 * Read and execute a job to/from @p ifd
 *
 * We assume the input and output fds are the same, which is true if
 * you're on a socket or tty.
 *
 * The compiler's arguments are munged so that it reads and writes
 * temporary files on the server, rather than whatever random
 * filenames the client had.  Similarly stderr and stdout are
 * redirected.
 *
 * There are two ways we can play this: either using a fifo or a regular
 * temporary file to feed input to the compiler.  In either case, we create
 * the file in the working directory and pass its name to the compiler as
 * input.
 *
 * The nice thing about using a FIFO is that we can overlap the start of
 * compilation with reading the preprocessed source from the network, which
 * possibly gives more even CPU utilization.  However, it doesn't work on
 * e.g. NFS-mounted /tmp, or Cygwin, and it might be interesting to test
 * relative performance.
 *
 * So we stop using FIFOs if --no-fifo was specified, or if creation fails.
 *
 * This is a bit complex because if using a FIFO we start the compiler before
 * we finish reading the request; otherwise we must obviously get the whole
 * input first.
 *
 * @todo It turns out that on NFS, you can create a FIFO, but you get
 * an error when you try to write to it.  This is pretty dumb, since
 * the operation could be done entirely locally anyhow.
 *
 * @return standard exit code
 **/
int dcc_accept_job(int fd)
{
    char **argv;
    int status;
    char *temp_i, *temp_o, *temp_err, *temp_out;
    size_t i_size = 0, o_size = 0;
    pid_t pid;
    int ret;
    char *orig_input, *orig_output;
    char *input_exten;
    long u_us, s_us;
    int use_fifo = !opt_no_fifo;
    
    /* Ignore SIGPIPE; we consistently check error codes and will
     * see the EPIPE. */
    signal(SIGPIPE, SIG_IGN);

    /* We log this here, rather than from the accept() call, because
     * we want to also work when running from inetd. */
    dcc_log_clientname(fd);

    tcp_cork_sock(fd, 1);

    if ((ret = dcc_r_request_header(fd)
         || dcc_r_argv(fd, &argv)))
        return ret;

    {
        char *a;
        a = dcc_argv_tostr(argv);
        rs_log_info("got arguments: %s", a);
        free(a);
    }
    
    if ((ret = dcc_scan_args(argv, &orig_input, &orig_output, &argv)))
        return ret;

    rs_log(RS_LOG_INFO|RS_LOG_NONAME, "input file %s, output file %s",
           orig_input, orig_output);

    input_exten = dcc_find_extension(orig_input);
    if (input_exten)
        input_exten = dcc_preproc_exten(input_exten);
    else
        input_exten = ".tmp";
    temp_i = dcc_make_tmpnam("server", input_exten);
    temp_o = dcc_make_tmpnam("server", ".out");
    temp_err = dcc_make_tmpnam("cc", ".err");
    temp_out = dcc_make_tmpnam("cc", ".out");

    if ((ret = dcc_set_input(argv, temp_i)
         || dcc_set_output(argv, temp_o)))
        return ret;

    if (use_fifo) {
        if (mkfifo(temp_i, S_IRUSR|S_IWUSR) == -1) {
            rs_log_warning("failed to make fifo %s: %s", temp_i, strerror(errno));
            rs_log_info("continuing without fifo");
            use_fifo = 0;
        }
    }

    if (!use_fifo) {
        /* read input before spawning */
        if ((ret = dcc_r_file(fd, temp_i, "DOTI", &i_size)) != 0)
            return ret;
    }

    if ((ret = dcc_spawn_child(argv, &pid, "/dev/null", temp_out, temp_err)) != 0)
        return ret;

    if (use_fifo) {
        /* read input after starting child */
        if ((ret = dcc_r_file(fd, temp_i, "DOTI", &i_size)) != 0)
            return ret;
    }
    
    ret = dcc_collect_child(pid, &status, &u_us, &s_us)
        || dcc_x_result_header(fd)
        || dcc_x_cc_status(fd, status)
        || dcc_x_file(fd, temp_err, "SERR", NULL)
        || dcc_x_file(fd, temp_out, "SOUT", NULL);

    if (ret == 0 && WIFEXITED(status) && WEXITSTATUS(status) == 0) {
        ret = dcc_x_file(fd, temp_o, "DOTO", &o_size);
    }

    dcc_report_rusage(argv[0], u_us, s_us);
    dcc_critique_status(status, argv[0], dcc_gethostname());
    rs_log(RS_LOG_INFO|RS_LOG_NONAME,
           "input file: %ld bytes; output file: %ld bytes",
           (long) i_size, (long) o_size);

    return ret;
}

