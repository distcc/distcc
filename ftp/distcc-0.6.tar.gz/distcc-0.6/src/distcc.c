/* -*- c-file-style: "java"; indent-tabs-mode: nil -*-
 * 
 * distcc -- A simple distributed compiler system
 * $Header: /data/cvs/distcc/src/distcc.c,v 1.87 2002/07/12 01:33:13 mbp Exp $ 
 *
 * Copyright (C) 2002 by Martin Pool <mbp@samba.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 */


			/* 4: The noise of a multitude in the
			 * mountains, like as of a great people; a
			 * tumultuous noise of the kingdoms of nations
			 * gathered together: the LORD of hosts
			 * mustereth the host of the battle.
			 *		-- Isaiah 13 */



#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "distcc.h"
#include "trace.h"
#include "io.h"
#include "rpc.h"
#include "exitcode.h"
#include "util.h"
#include "clinet.h"

/* for trace.c */
const char *rs_program_name = "distcc";

/**
 * @file
 *
 * Entry point for the distcc client.
 *
 * In most parts of this program, functions return -1 for failure and
 * 0 for success.
 *
 * @todo Make sure that if we fail, the .o file is removed.
 **/


static void dcc_show_usage(void)
{
    dcc_show_version("distcc");
    dcc_show_copyright();
    printf(
"Usage:\n"
"   distcc gcc [compile options] -o OBJECT -c SOURCE\n"
"   distcc --help\n"
"\n"
"Options:\n"
"   --help                     explain usage and exit\n"
"   --version                  show version and exit\n"
"\n"
"Environment variables:\n"
"   DISTCC_HOSTS=\"HOST ...\"\n"
"            list of volunteer hosts, should include localhost\n"
"   DISTCC_VERBOSE=1           give debug messages\n"
"   DISTCC_LOG=LOGFILE         send messages here, not stderr\n"
"\n"
"distcc distributes compilation jobs across volunteer machines running\n"
"distccd.  Jobs that cannot be distributed, such as linking or \n"
"preprocessing are run locally.  distcc should be used with make's -jN\n"
"option to execute in parallel on several machines.\n"
);
}


static int dcc_write_header(int fd)
{
	return dcc_write_str(fd, "DIST")
		|| dcc_write_int(fd, PROTO_VER);
}



static int dcc_x_argv(int fd, char **argv)
{
    int i;
    int argc;
    
    argc = dcc_argv_len(argv);
    
    if (dcc_write_str(fd, "ARGC") || dcc_write_int(fd, (unsigned) argc))
        return -1;
    
    for (i = 0; i < argc; i++) {
        if (dcc_write_str(fd, "ARGV")
            || dcc_write_int(fd, (unsigned) strlen(argv[i]))
            || dcc_write_str(fd, argv[i]))
            return -1;
    }

    return 0;
}


			   
/**
 * Top-level function to run remotely.
 *
 * @param cpp_pid If nonzero, the pid of the preprocessor.  Must be
 * allowed to complete before we send the input file.
 *
 * @param status on return contains the wait-status of the remote
 * compiler.
 *
 * @return 0 on success, otherwise error.  Returning nonzero does not
 * necessarily imply the remote compiler itself succeeded, only that
 * there were no communications problems.
 **/
static int dcc_compile_remote(char **argv, 
                              char *cpp_fname, char *output_fname,
                              pid_t cpp_pid,
                              const char *buildhost,
                              int *status)
{
    int fd;
    long stime_usec, utime_usec;
    int ret;

    dcc_note_execution(buildhost, argv);
    if ((ret = dcc_open_socket_out(buildhost, 4200, &fd)) != 0)
        return ret;

    tcp_cork_sock(fd, 1);

    if (dcc_write_header(fd)
        || dcc_x_argv(fd, argv))
        return -1;

    if (cpp_pid) {
        if (dcc_collect_child(cpp_pid, status, &utime_usec, &stime_usec)
            || dcc_report_rusage("cpp", utime_usec, stime_usec)
            || dcc_critique_status(*status, "cpp", "localhost"))
            return -1;
    }

    if (dcc_x_file(fd, cpp_fname, "DOTI", NULL))
        return -1;

    tcp_cork_sock(fd, 0);
    rs_trace("client finished sending request to server");

    if (dcc_r_result_header(fd)
        || dcc_r_cc_status(fd, status)
        || dcc_r_fd(fd, STDERR_FILENO, "SERR", NULL)
        || dcc_r_fd(fd, STDOUT_FILENO, "SOUT", NULL))
        return -1;

    /* Only try to retrieve the .o file if the compiler completed
     * successfully */
    if (WIFEXITED(*status) && WEXITSTATUS(*status) == 0) {
        if (dcc_r_file(fd, output_fname, "DOTO", NULL))
            return -1;
    } else {
        rs_log_warning("compiler failed (waitstatus %#x); "
                       "skipping retrieval of object file",
                       *status);
    }

    return 0;
}


/**
 * If the input filename is a plain source file rather than a
 * preprocessed source file, then preprocess it to a temporary file
 * and return the name in @p cpp_fname.
 *
 * The preprocessor may still be running when we return; you have to
 * wait for @p cpp_fid to exit before the output is complete.  This
 * allows us to overlap opening the TCP socket, which probably doesn't
 * use many cycles, with running the preprocessor.
 **/
static int dcc_cpp_maybe(char **argv, char *input_fname, char **cpp_fname,
                         pid_t *cpp_pid)
{
    char **cpp_argv;

    *cpp_pid = 0;
    
    if (dcc_is_preprocessed(input_fname)) {
        /* already preprocessed, great. */
        *cpp_fname = strdup(input_fname);
        return 0;
    }

    if (dcc_deepcopy_argv(argv, &cpp_argv))
        return -1;
    *cpp_fname = dcc_make_tmpnam("cppout", ".i");

    /* TODO: Rather than sending the output to a temporary file, get
     * the preprocessor to write to a pipe so that we can start
     * sending it directly.
     *
     * TODO: Don't wait for the preprocessor to finish before trying
     * to connect.  Instead, set it going, and then start opening the
     * remote socket, because that will probably take a while. */

    return dcc_set_action_opt(cpp_argv, "-E")
        || dcc_set_output(cpp_argv, *cpp_fname)
        || dcc_spawn_child(cpp_argv, cpp_pid, "/dev/null", NULL, NULL);
}


/**
 * Invoke a compiler locally.  This is, obviously, the alternative to
 * dcc_compile_remote().
 *
 * The server does basically the same thing, but it doesn't call this
 * routine because it wants to overlap execution of the compiler with
 * copying the input from the network.
 *
 * This routine used to exec() the compiler in place of distcc.  That
 * is slightly more efficient, because it avoids the need to create,
 * schedule, etc another process.  The problem is that in that case we
 * can't clean up our temporary files, and (not so important) we can't
 * log our resource usage.
 **/
static int dcc_compile_local(char *argv[])
{
    pid_t pid;
    int ret;
    int status;
    long u_us, s_us;
    
    char *buildhost = "localhost";
    dcc_note_execution(buildhost, argv);

    /* We don't do any redirection of file descriptors when running locally,
     * so if for example cpp is being used in a pipeline we should be fine. */
    if ((ret = dcc_spawn_child(argv, &pid, NULL, NULL, NULL)) != 0)
        return ret;

    if ((ret = dcc_collect_child(pid, &status, &u_us, &s_us)))
        return ret;

    dcc_report_rusage(argv[0], u_us, s_us);
    return dcc_critique_status(status, "compile", dcc_gethostname());
}


/**
 * Execute the commands in argv remotely or locally.
 *
 * We may need to run cpp locally; we can do that in the background
 * while trying to open a remote connection.  If something fails while
 * trying to do that, then we need to
 *
 * @param argv Command to execute.  Does not include 0='distcc'.
 * Treated as read-only, because it is a pointer to the program's real
 * argv.
 *
 * @todo We want to eventually make sure to always fall back to
 * compiling locally if possible, so that the disruption from a
 * damaged network is minimized.  On the other hand, if there really
 * is a problem remotely, we want to report it.
 **/
static int dcc_build_somewhere(char *argv[], int *status)
{
    char *input_fname, *output_fname, *cpp_fname;
    pid_t cpp_pid = 0;
    int ret;
    char *buildhost;
    int must_be_local = 0;

    if (dcc_scan_args(argv, &input_fname, &output_fname, &argv) != 0) {
        /* we need to scan the arguments even if we already know it's local, so that
         * we can pick up distcc client options. */
        must_be_local = 1;
    }

    if ((ret = dcc_pick_buildhost(&buildhost)) != 0)
        return ret;

    if (strcmp(buildhost, "localhost") == 0)
        must_be_local = 1;
    
    if (must_be_local) {
        /* This one returns -1 for jobs that can't be remote. */
        return dcc_compile_local(argv);
    } else {
        if ((ret = dcc_cpp_maybe(argv, input_fname, &cpp_fname, &cpp_pid) != 0))
            return ret;
        
        if ((ret = dcc_compile_remote(argv, cpp_fname, output_fname,
                                      cpp_pid, buildhost, status)) != 0)
            return ret;
        
        return dcc_critique_status(*status, argv[0], buildhost);
    }
}


static void dcc_set_trace_from_env(void)
{
    const char *e;
    const char *logfile;

    if ((logfile = getenv("DISTCC_LOG"))) {
        int fd;

        rs_trace_set_level(RS_LOG_INFO);

        /* XXX: tridge warns that O_CREAT ought to use O_EXCL */
        fd = open(logfile, O_WRONLY|O_APPEND|O_CREAT, 0666);
        if (fd == -1) {
            rs_log_error("failed to open logfile %s: %s",
                         logfile, strerror(errno));
        }
        rs_trace_fd = fd;
    } else {
        rs_trace_set_level(RS_LOG_WARNING);
    }

    e = getenv("DISTCC_VERBOSE");
    if (e && *e) {
        rs_trace_set_level(RS_LOG_DEBUG);
    }
}


int main(int argc, char **argv)
{
    int status;

    atexit(dcc_cleanup_tempfiles);

    dcc_set_trace_from_env();

    if (argc <= 1 || !strcmp(argv[1], "--help")) {
        dcc_show_usage();
        exit(0);
    } else if (!strcmp(argv[1], "--version")) {
        dcc_show_version("distcc");
        exit(0);
    } 

    dcc_exit(dcc_build_somewhere(&argv[1], &status));
}
