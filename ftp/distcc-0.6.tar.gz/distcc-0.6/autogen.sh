#! /bin/sh

# Run this script to build distcc from CVS.

# $Header: /data/cvs/distcc/autogen.sh,v 1.6 2002/06/27 03:23:41 mbp Exp $

if which autoconf > /dev/null
then
    :
else
    echo "$0: need autoconf 2.53 or later to build distcc from CVS" >&2
    exit 1
fi

echo "$0: running aclocal to install aclocal.m4"
aclocal || exit 1

echo "$0: running autoheader"
autoheader || exit 1

echo "$0: running autoconf"
autoconf || exit 1
echo "Now run ./configure and then make."
echo "(If you wish, you can build in a directory separate from the source "
echo "by running $srcdir/configure from that location.)"
exit 0
