/* -*- c-file-style: "java"; indent-tabs-mode: nil -*-
 * 
 * distcc -- A simple distributed compiler system
 * $Header: /data/cvs/distcc/src/where.c,v 1.31 2002/09/13 23:47:10 mbp Exp $ 
 *
 * Copyright (C) 2002 by Martin Pool <mbp@samba.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 */


                /* His hand is stretched out, and who shall turn it
                 * back?  -- Isaiah 14:27 */

    
/**
 * @file
 *
 * Routines to look at the <tt>$DISCC_HOSTS</tt> and decide where to
 * run a job.
 *
 * We use a simple locking algorithm to try to make sure work is fairly
 * evenly distributed across all hosts.
 *
 * For each destination host, we keep a lock file in the temporary
 * directory.  A lock is held on that file all the time that a client
 * is connected to it, so that other invocations of distcc on the same
 * client machine by the same user can synchronize with it.
 *
 * There are an unbounded number of lock files for each volunteer,
 * from 0 up.  We repeatedly walk through all the volunteers in order
 * until we find a lock file that is not locked; we then try to
 * connect to that server.
 *
 * So whatever -j value you give to make, you should end up with
 * roughly that number of tasks running at any time, except that
 * remote tasks may be deferred in their accept queue until the
 * machine is ready to serve them.
 *
 * We use locks rather than e.g. deleting files because we want to
 * make sure that the lock will be removed if the client terminates
 * unexpectedly.  There is in fact no explicit unlock: the lock goes
 * away when the client terminates.
 *
 * The files themselves (as opposed to the lock on them) is never
 * cleaned up; since locking & creation is nonatomic I can't think of
 * a clean way to do it.  There shouldn't be many of them, and dead
 * ones will be caught by the tmpreaper.  In any case they're zero
 * bytes.
 *
 * Semaphores might work well here, but the interface is a bit ugly
 * and they have a reputation for being nonportable.
 */

#define _GNU_SOURCE

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>

#include <sys/stat.h>
#include <sys/file.h>

#include "distcc.h"
#include "trace.h"
#include "util.h"
#include "hosts.h"
#include "tempfile.h"
#include "lock.h"


/* TODO: Write a test harness for the host selection algorithm.
 * Perhaps a really simple simulation of machines taking different
 * amounts of time to build stuff? */

int dcc_pick_buildhost(const struct dcc_hostdef **buildhost)
{
    int i_try;
    int n_hosts;
    struct dcc_hostdef *hostlist, *h;
    int ret;

    if ((ret = dcc_parse_hosts_env(&hostlist, &n_hosts)) != 0) {
        /* an error occured; but let's be helpful and build locally
         * rather than giving up. */
        *buildhost = dcc_hostdef_local;
        return 0;
    }

    for (i_try = 0; i_try < 50; i_try++) {
        for (h = hostlist; h; h = h->next) {
            if (dcc_try_lock_host(h, i_try) == 0) {
                rs_trace("building on %s", h->hostname);
                *buildhost = h;
                return 0;
            }
        }
    }
    
    rs_log_warning("couldn't lock any of the %d defined hosts!", n_hosts);
    *buildhost = dcc_hostdef_local;
    return 0;
}
