#! /usr/bin/env python2.2

"""distcc test suite, using comfychair

This script is called with $PATH pointing to the appropriate location
for the built (or installed) programs to be tested.

Copyright (C) 2002 by Martin Pool
"""


# There are pretty strong hierarchies of test cases: ones to do with
# running a daemon, compiling a file and so on.  This nicely maps onto
# a hierarchy of object classes.

# It seems to work best if an instance of the class corresponds to an
# invocation of a test: this means each method runs just once and so
# object state is not very useful, but nevermind.

# Having a complicated pattens of up and down-calls within the class
# methods seems to make things more complicated.  It may be better if
# abstract superclasses just provide methods that can be called,
# rather than establishing default behaviour.



# TODO: Put scratch files into a temporary directory; kill it after
# each test.

# TODO: Try compiling a file locally and remotely; check that they are
# the same.

# TODO: Compile locally to .s, and assemble remotely; check that
# works.

# TODO: Check that successful compilations produce nothing on stdout
# or stderr.

# TODO: Add a base class that launches a daemon on some port and shuts
# it down again when done.  The Bitkeeper approach is to give the
# daemon a distinct exit code for "unable to bind socket", and to then
# just keep bumping that up until we find one that's not in use.  That
# way the shell script knows where the server is and it can point the
# client at the same port.

# Also we want some tests that use whatever is already set up in the
# user's environment, because they may have some remote machines we
# can use.  Also check that we correctly handle the case where the
# daemon's already gone and so can't take connections.

# TODO: Some kind of direct test of the host selection algorithm.

# TODO: Optionally run all discc tests under Valgrind, ElectricFence
# or something similar.

# TODO: Test that ccache correctly caches compilations through distcc:
# make up a random file so it won't hit, then compile once and compile
# twice and examine the log file to make sure we got a hit.  Also
# check that the binary works properly.

# TODO: Test cpp on non-C file (like .Xresources)

# TODO: Test cpp from stdin

# TODO: Do all this with malloc debugging on.

# TODO: Redirect daemon output to a file so that we can more easily
# check it.  Is there a straightforward way to test that it's also OK
# when send through syslogd?

# TODO: Check behaviour when children are killed off.

# TODO: Test compiling over IPv6

# TODO: Argument scanning tests should be run with various hostspecs,
# because that makes a big difference to how the client handles them.

# TODO: Test --no-fork mode

# TODO: Test --inetd mode by creating a socketpair ourselves

# TODO: Test that ccache gets hits when calling distcc.  Presumably
# this is skipped if we can't find ccache.  Need to parse `ccache -s`.

import time, sys, string, os, types, unittest, re, popen2, pprint
import signal, os.path
import comfychair

EXIT_DISTCC_FAILED           = 100
EXIT_BAD_ARGUMENTS           = 101
EXIT_BIND_FAILED             = 102
EXIT_CONNECT_FAILED          = 103
EXIT_COMPILER_CRASHED        = 104
EXIT_OUT_OF_MEMORY           = 105
EXIT_BAD_HOSTSPEC            = 106


basedir = os.getcwd()

class SimpleDistCC_Case:
    '''Abstract base class for distcc tests'''
    def __init__(self):
        self.cmd_log = ''

    def setUp(self):
        self.enterTmpDir()
        self.stripEnvironment()
        pass

    def enterTmpDir(self):
        """Create and enter a temporary directory for this test."""
        self.basedir = basedir
        self.tmpdir = os.path.join(self.basedir,
                                   'testtmp', 
                                   self.__class__.__name__ + ".tmp")
        os.system("rm -fr %s" % self.tmpdir)
        os.makedirs(self.tmpdir)
        os.system("mkdir -p %s" % self.tmpdir)
        os.chdir(self.tmpdir)

    def stripEnvironment(self):
        """Remove all DISTCC variables from the environment, so that
        the test is not affected by the development environment."""
        for key in os.environ.keys():
            if key[:7] == 'DISTCC_':
                # NOTE: This only works properly on Python 2.2: on
                # earlier versions, it does not call unsetenv() and so
                # subprocesses may get confused.
                del os.environ[key]

    def tearDown(self):
        self.leaveTmpDir()

    def leaveTmpDir(self):
        os.chdir(self.basedir)

    def explain_failure(self):
        print self.cmd_log
    
    def _run(self):
        """Private method that executes the whole test, including setup and
        teardown"""
        try:
            self.setUp()
            self.runTest()
        finally:
            self.tearDown()

    def fail(self, msg):
        raise AssertionError(msg)

    def assertEquals(self, a, b):
        if not a == b:
            raise AssertionError("assertEquals failed: %s" % `(a, b)`)
            
    def assertNotEqual(self, a, b):
        if a == b:
            raise AssertionError("assertNotEqual failed: %s" % `(a, b)`)

    def assertReMatch(self, needle, haystack):
        """Look for the regular expression re in haystack"""
        if not re.search(needle, haystack):
            self.fail("couldn't find re %s in %s" % (`needle`, `haystack`))
            

class RunCmd_Case(SimpleDistCC_Case):
    '''A test case that involves running distcc and looking at the output.'''
    def __init__(self):
        SimpleDistCC_Case.__init__(self)
        self.background_pids = []

    def tearDown(self):
        self.kill_backgrounded()
        SimpleDistCC_Case.tearDown(self)
    
    def run_cmd_unchecked(self, cmd, mcheck=1):
        '''Invoke a distcc command; return (exitcode, stdout)'''
        if mcheck:
            cmd = "MALLOC_CHECK_=2 " + cmd
        pobj = popen2.Popen4(cmd)
        output = pobj.fromchild.read()
        waitstatus = pobj.wait()
        assert not os.WIFSIGNALED(waitstatus), ("%s terminated with signal %d",
                                                cmd, os.WTERMSIG(waitstatus))
        rc = os.WEXITSTATUS(waitstatus)
        self.cmd_log += ("""Run command: %s
Wait status: %#x
Output:
%s""" % (cmd, waitstatus, output))
        return rc, output


    def run_cmd(self, cmd, expectedResult = 0):
        rc, output = self.run_cmd_unchecked(cmd)
        if rc != expectedResult:
            self.fail("command returned %d; expected %s: \"%s\"" %
                      (rc, expectedResult, cmd))
            
        return output


    def run_backgrounded(self, cmd):
        """Start a command in the background and remember its pid."""
        pid = os.spawnl(os.P_NOWAIT, "/bin/sh", "-x", "-p", "-c", cmd)
        self.cmd_log += ("""Run command backgrounded: %s
Pid: %d
""" % (cmd, pid))
        self.background_pids.append(pid)


    def kill_backgrounded(self):
        for pid in self.background_pids:
            os.kill(pid, signal.SIGTERM)

            
class WithDaemon_Case(RunCmd_Case):
    """Start the daemon, and then run a command locally against it.
"""
    
    def setUp(self):
        RunCmd_Case.setUp(self)
        self.daemon_pidfile = os.path.join(os.getcwd(), "daemonpid.tmp")
        self.startDaemon()
        self.setupEnv()

    def setupEnv(self):
        os.environ['DISTCC_HOSTS'] = '127.0.0.1:%d' % self.server_port

    def tearDown(self):
        self.killDaemon()
        RunCmd_Case.tearDown(self)

    def killDaemon(self):
        self.run_cmd("kill `cat %s`" % self.daemon_pidfile)
        self.run_cmd("sleep 1")

    def startDaemon(self):
        # eventually we ought to try different ports until we succeed
        self.server_port = 42000
        cmd = ("distccd --daemon --log-stderr --pid-file %s --port %d"
               % (self.daemon_pidfile, self.server_port))
        self.run_cmd(cmd)
        

class StartStopDaemon_Case(WithDaemon_Case):
    def runTest(self):
        pass


class VersionOption_Case(RunCmd_Case):
    """Test that --version returns some kind of version string.

    This is also a good test that the programs were built properly and are
    executable."""
    def runTest(self):
        for prog in 'distcc', 'distccd':
            out = self.run_cmd("%s --version" % prog)
            assert out[-1] == '\n'
            out = out[:-1]
            line1,trash = out.split('\n')
            comfychair.assert_re_match(r'^%s [\w.]+ [.\w-]+ \(protocol 1\)$' % prog, line1)


class HelpOption_Case(RunCmd_Case):
    """Test --help is reasonable."""
    def runTest(self):
        for prog in 'distcc', 'distccd':
            out = self.run_cmd(prog + " --help")
            comfychair.assert_regexp("Usage:", out)


class BogusOption_Case(RunCmd_Case):
    """Test handling of --bogus-option."""
    def runTest(self):
        for prog in 'distcc', 'distccd':
            self.run_cmd(prog + " --bogus-option", EXIT_BAD_ARGUMENTS)
            

class GccOptionsPassed_Case(RunCmd_Case):
    """Test that options following the compiler name are passed to the compiler."""
    def runTest(self):
        out = self.run_cmd("DISTCC_HOSTS=localhost distcc gcc --help")
        if re.search('distcc', out):
            raise ("gcc help contains \"distcc\": \"%s\"" % out)
        comfychair.assert_re_match(r"^Usage: gcc", out)


class IsSource_Case(RunCmd_Case):
    def runTest(self):
        """Test distcc's method for working out whether a file is source"""
        cases = (( "hello.c",          "source",       "not-preprocessed" ),
                 ( "hello.cpp",        "source",       "not-preprocessed" ),
                 ( "hello.2.4.4.i",    "source",       "preprocessed" ),
                 ( ".foo",             "not-source",   "not-preprocessed" ),
                 ( "gcc",              "not-source",   "not-preprocessed" ),
                 ( "hello.ii",         "source",       "preprocessed" ),
                 ( "hello.c++",        "source",       "not-preprocessed" ),
                 ( "boot.s",           "source",       "preprocessed" ),
                 ( "boot.S",           "source",       "not-preprocessed" ))
        for f, issrc, iscpp in cases:
            o = self.run_cmd("h_issource '%s'" % f)
            expected = ("%s %s\n" % (issrc, iscpp))
            if o != expected:
                raise AssertionError("issource %s gave %s, expected %s" %
                                     (f, `o`, `expected`))



class ScanArgs_Case(RunCmd_Case):
    '''Test understanding of gcc command lines'''
    def runTest(self):
        cases = [("gcc -c hello.c", "distribute", "hello.c", "hello.o"),
                 ("gcc hello.c", "local"),
                 ("gcc -o /tmp/hello.o -c ../src/hello.c", "distribute", "../src/hello.c", "/tmp/hello.o"),
                 ("gcc -DMYNAME=quasibar.c bar.c -c -o bar.o", "distribute", "bar.c", "bar.o"),
                 ("gcc -ohello.o -c hello.c", "distribute", "hello.c", "hello.o"),
                 ("ccache gcc -c hello.c", "distribute", "hello.c", "hello.o"),
                 ("gcc hello.o", "local"),
                 ("gcc -o hello.o hello.c", "local"),
                 ("gcc -o hello.o -c hello.s", "distribute", "hello.s", "hello.o"),
                 ("gcc -fprofile-arcs -ftest-coverage -c hello.c", "local", "hello.c", "hello.o"),
                 ]
        for tup in cases:
            self.checkScanArgs(*tup)

    def checkScanArgs(self, ccmd, mode, input=None, output=None):
        o = self.run_cmd("h_scanargs %s" % ccmd)
        o = o[:-1]                      # trim \n
        os = string.split(o)
        if mode != os[0]:
            self.fail("h_scanargs %s gave %s mode, expected %s" % (ccmd, os[0], mode))
        if mode == 'distribute':
            if os[1] <> input:
                self.fail("h_scanargs %s gave %s input, expected %s" % (ccmd, os[1], input))
            if os[2] <> output:
                self.fail("h_scanargs %s gave %s output, expected %s" % (ccmd, os[2], output))


class ExtractExtension_Case(RunCmd_Case):
    def runTest(self):
        """Test extracting extensions from filenames"""
        for f, e in (("hello.c", ".c"),
                     ("hello.cpp", ".cpp"),
                     ("hello.2.4.4.4.c", ".c"),
                     (".foo", ".foo"),
                     ("gcc", "(NULL)")):
            out = self.run_cmd("h_exten '%s'" % f)
            assert out == e


class NoCompiler_Case(RunCmd_Case):
    def runTest(self):
        """Test giving no compiler gives expected error"""
        self.run_cmd("distcc -c hello.c -o hello.o", EXIT_BAD_ARGUMENTS)
        

class DaemonBadPort_Case(RunCmd_Case):
    def runTest(self):
        """Test daemon invoked with invalid port number"""
        self.run_cmd("rm -f daemonpid.tmp")
        self.run_cmd("distccd --pid-file daemonpid.tmp --port 80000", EXIT_BIND_FAILED)
        comfychair.assert_no_file("daemonpid.tmp")


class InvalidHostSpec_Case(RunCmd_Case):
    def runTest(self):
        """Test various invalid DISTCC_HOSTS
        
        See also test_parse_host_spec, which tests valid specifications."""
        for spec in ["", "    ", "\t", "  @ ", ":", "mbp@", "angry::", ":4200"]:
            self.run_cmd("DISTCC_HOSTS=\"%s\" h_hosts -v" % spec,
                              EXIT_BAD_HOSTSPEC)


class ParseHostSpec_Case(RunCmd_Case):
    def runTest(self):
        """Check operation of dcc_parse_hosts_env.

        Passes complex environment variables to h_hosts, which is a C wrapper
        that calls the appropriate tests."""
        spec="""localhost 127.0.0.1 @angry   ted@angry
        \t@angry:/home/mbp/bin/distccd  angry:4204
        ipv4-localhost
        """
        expected="""7
LOCAL
TCP 127.0.0.1 4200
SSH (no-user) angry (no-command)
SSH ted angry (no-command)
SSH (no-user) angry /home/mbp/bin/distccd
TCP angry 4204
TCP ipv4-localhost 4200
"""
        out = self.run_cmd("DISTCC_HOSTS=\"%s\" h_hosts" % spec)
        assert out == expected, "expected %s\ngot %s" % (`expected`, `out`)


class Compilation_Case(WithDaemon_Case):
    '''Test distcc by actually compiling a file'''
    def setUp(self):
        WithDaemon_Case.setUp(self)
        self.createSource(self.sourceFilename(), self.source())

    def runTest(self):
        self.compile()
        self.checkBuiltProgram()

    def createSource(self, filename, contents):
        f = open(filename, 'w')
        f.write(contents)
        f.close()

    def sourceFilename(self):
        return "testtmp.c"              # default
    
    def compile(self):
        msgs = self.run_cmd(self.compileCmd())
        msgs += self.run_cmd(self.linkCmd())
        self.checkCompileMsgs(msgs)

    def compileCmd(self):
        """Return command to compile source and run tests"""
        return "distcc cc -o testtmp.o -c %s" % (self.sourceFilename())

    def linkCmd(self):
        return "distcc cc -o testtmp testtmp.o"

    def checkCompileMsgs(self, msgs):
        if msgs <> '':
            self.fail("expected no compiler messages, got \"%s\""
                      % msgs)

    def checkBuiltProgram(self):
        '''Check compile results.  By default, just try to execute.'''
        msgs = self.run_cmd("./testtmp")
        self.checkBuiltProgramMsgs(msgs)

    def checkBuiltProgramMsgs(self, msgs):
        pass


class CompileHello_Case(Compilation_Case):
    """Test the simple case of building a program that works properly"""
    def source(self):
        return """
#include <stdio.h>

int main(void) {
    puts("hello world");
    return 0;
}
"""

    def checkBuiltProgramMsgs(self, msgs):
        self.assertEquals(msgs, "hello world\n")


class NoServer_Case(CompileHello_Case):
    """Invalid server name"""
    def setUp(self):
        self.enterTmpDir()
        self.stripEnvironment()
        os.environ['DISTCC_HOSTS'] = 'no.such.host.here'
        self.distcc_log = 'distcc.log'
        os.environ['DISTCC_LOG'] = self.distcc_log
        
    def runTest(self):
        self.createSource('hello.c', 'int main() {}')
        self.run_cmd("distcc gcc -c -o hello.o hello.c")
        msgs = open(self.distcc_log, 'r').read()
        self.assertReMatch(r'failed to distribute, running locally instead',
                           msgs)            
        
    def tearDown(self):
        self.leaveTmpDir()

        
class ImpliedOutput_Case(CompileHello_Case):
    """Test handling absence of -o"""
    def compileCmd(self):
        return "distcc cc -c testtmp.c"


class SyntaxError_Case(Compilation_Case):
    """Test building a program containing syntax errors, so it won't build
    properly."""
    def source(self):
        return """not C source at all
"""

    def compile(self):
        rc, msgs = self.run_cmd_unchecked(self.compileCmd())
        self.assertNotEqual(rc, 0)
        # XXX: Need to also handle "syntax error" from gcc-2.95.3
        if not re.match(r'testtmp.c:1: .*error', msgs):
            self.fail("compiler error not as expected: \"%s\"" %
                      msgs)

    def linkCmd(self):
        return ":"                      # don't link

    def checkBuiltProgram(self):
        """Shouldn't have built"""
        if os.path.exists("testtmp") or os.path.exists("testtmp.o"):
            self.fail("compiler produced output, but should not have done so")


class NoHosts_Case(CompileHello_Case):
    """Test running with no hosts defined.

    We expect compilation to succeed, but with a warning that it was
    run locally."""
    def setupEnv(self):
        # WithDaemon_Case sets this to point to the local host, but we don't.
        pass

    def checkCompileMsgs(self, msgs):
        "We expect only one message, a warning from distcc"
        if not re.search(r"Warning.*\$DISTCC_HOSTS.*can't distribute work",
                         msgs):
            self.fail("did not find expected warning about HOSTS in \"%s\"; %s"
                      % (msgs, pprint.pformat(os.environ)))


class RemoteAssemble_Case(CompileHello_Case):
    """Test remote assembly of a .s file."""

    # We have a rather tricky method for testing assembly code when we
    # don't know what platform we're on.  I think this one will work
    # everywhere, though perhaps not.
    asm_source = """
        .file	"foo.c"
	.version	"01.01"
gcc2_compiled.:
.globl msg
.section	.rodata
.LC0:
	.string	"hello world"
.data
	.align 4
	.type	 msg,@object
	.size	 msg,4
msg:
	.long .LC0
	.ident	"GCC: (GNU) 2.95.4 20011002 (Debian prerelease)"
"""

    def source(self):
            return """
#include <stdio.h>

extern const char *msg;

int main(void) {
    puts(msg);
    return 0;
}
"""
    asm_filename = 'test2.s'

    def setUp(self):
        CompileHello_Case.setUp(self)
        self.createSource(self.asm_filename, self.asm_source)
        
        # TODO: Delete temp files

    def compile(self):
        msgs = self.run_cmd(self.compileCmd()) \
               + self.run_cmd(self.asmCmd()) \
               + self.run_cmd(self.linkCmd())
        self.checkCompileMsgs(msgs)

    def compileCmd(self):
        return "distcc cc -o testtmp.o -c testtmp.c" 

    def asmCmd(self):
        return "distcc cc -o test2.o -c %s" % (self.asm_filename)

    def linkCmd(self):
        return "distcc cc -o testtmp testtmp.o test2.o"


class PreprocessAsm_Case(RemoteAssemble_Case):
    """Run preprocessor locally on assembly, then compile locally."""
    asm_source = """
#define MSG "hello world"
gcc2_compiled.:
.globl msg
.section	.rodata
.LC0:
	.string	 MSG
.data
	.align 4
	.type	 msg,@object
	.size	 msg,4
msg:
	.long .LC0
"""
    asm_filename = 'test2.S'
    

    def asmCmd(self):
        return "distcc cc -o test2.o -c test2.S" 



def test_unresolvable_server():
    """Test handling of an unresolvable host"""


def test_unreachable_server():
    """Test handling of a host that (probably) can't be reached"""


if __name__ == '__main__':
    comfychair.runtests([ScanArgs_Case,
                         StartStopDaemon_Case,
                         CompileHello_Case,
                         VersionOption_Case,
                         HelpOption_Case,
                         BogusOption_Case,
                         GccOptionsPassed_Case,
                         IsSource_Case,
                         ExtractExtension_Case,
                         NoCompiler_Case,
                         DaemonBadPort_Case,
                         NoServer_Case,
                         InvalidHostSpec_Case,
                         ParseHostSpec_Case,
                         ImpliedOutput_Case,
                         SyntaxError_Case,
                         NoHosts_Case,
                         RemoteAssemble_Case,
                         PreprocessAsm_Case])
    
