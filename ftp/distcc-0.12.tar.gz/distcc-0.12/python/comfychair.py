#! /usr/bin/env python

"""comfychair: a Python-based instrument of software torture.


Copyright (C) 2002 by Martin Pool <mbp@samba.org>

This software may be used, modified and distributed without
restriction, except that this copyright notice must be retained.  This
software comes with ABSOLUTELY NO WARRANTY of any kind.


This is a test framework designed for testing programs written in
Python, or (through a fork/exec interface) any other language.  It is
similar in design to the very nice 'svntest' system used by
Subversion, but has no Subversion-specific features.

It is somewhat similar to PyUnit, except:

 - it allows capture of detailed log messages from a test, to be
   optionally displayed if the test fails.

 - it allows execution of a specified subset of tests

 - it avoids Java idioms that are not so useful in Python

WRITING TESTS:

  Each test case is a callable object, typically a function.  Its
  documentation string describes the test, and the first line of the
  docstring should be a brief name.

  The test should return 0 for pass, or non-zero for failure.
  Alternatively they may raise an exception.

  Tests may import this "comfychair" module to get some useful
  utilities, but that is not strictly required.
  
"""

# TODO: Put everything into a temporary directory?

# TODO: Have a means for tests to customize the display of their
# failure messages.  In particular, if a shell command failed, then
# give its stderr.

__version__ = '$Header: /data/cvs/distcc/python/comfychair.py,v 1.12 2002/08/29 00:17:16 mbp Exp $'

def _test_name(test):
    """Return a human-readable name for a test.

    Inputs:
      test         some kind of callable test object

    Returns:
      name         string: a short printable name
      """
    try:
        return test.__name__
    except:
        return `test`


def assert_re_match(pattern, s):
    """Assert that a string matches a particular pattern

    Inputs:
      pattern      string: regular expression
      s            string: to be matched

    Raises:
      AssertionError if not matched
      """
    import re
    if not re.match(pattern, s):
        raise AssertionError("string %s does not match regexp %s" % (`s`, `pattern`))

def assert_regexp(pattern, s):
    """Assert that a string *contains* a particular pattern

    Inputs:
      pattern      string: regular expression
      s            string: to be searched

    Raises:
      AssertionError if not matched
      """
    import re
    if not re.search(pattern, s):
        raise AssertionError("string %s does not contain regexp %s" % (`s`, `pattern`))


def assert_no_file(filename):
    import os.path
    assert not os.path.exists(filename), ("file exists but should not: %s" % filename)


def runtests(test_list):
    """Run a series of tests.

    Eventually, this routine will also examine sys.argv[] to handle
    extra options.

    Inputs:
      test_list    sequence of callable test objects

    Returns:
      nothing
    """
    import sys, traceback
    for test in test_list:
        print "%-60s" % _test_name(test),
        # flush now so that long running tests are easier to follow
        sys.stdout.flush()
        try:
            obj = test()
            obj._run()
            print "OK"
        except:
            print "FAIL"
            print "-----------------------------------------------------------------"
            traceback.print_exc(file=sys.stdout)
            obj.explain_failure()
            print "-----------------------------------------------------------------"

    # TODO: Perhaps save up the exceptions and print them all in one
    # go at the end, like PyUnit.
            

if __name__ == '__main__':
    print __doc__
    
